import express from 'express';
import producto_categoriasRutas from './rutas/producto_categoriasRutas.js';
//import mysql from 'mysql2/promise'; // Usamos la versión con Promesas
const app = express();
app.use(express.json())

app.use('/',producto_categoriasRutas)

const puerto = 3001;
app.listen(puerto,
    () => { console.log(`Servidor en http://localhost:${puerto}`);
});

//No hacer una eliminacion fisica, hacer una eliminacion logica