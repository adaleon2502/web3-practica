import {obtTodoCategoria, obtTodoIDCategoria, insertaCategoria, actualizaCat, eliminaCat, insertaProd, obtTodoProd, obtTodoIDProd, actualizaProd, actualiza_stock} from "../modelos/producto_categoriasModelo.js";

export const muestraCategorias = async (req, res) => {
    try {
    const resultado = await obtTodoCategoria();
    res.json(resultado);
    } catch (error) {
    res.status(500).json({ error: error.message });
    }
};

export const muestraIDCategoria = async (req, res) => {
    try {
    const resultado = await obtTodoIDCategoria(req.params.id);
    res.json(resultado);
    } catch (error) {
    res.status(500).json({ error: error.message });
    }
};

export const insertarCategoria = async (req, res) => {
    try {
    const resultado = await insertaCategoria(req.body);
    res.status(201).json(resultado);
    } catch (error) {
    res.status(500).json({ error: error.message });
    }
}; 

export const actualizaCategoria = async (req, res) => {
    try {
        const resultado = await actualizaCat(req.params.id, req.body);
        res.json(resultado);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

export const eliminaCategoria = async (req, res) => {
    try {
       await eliminaCat(req.params.id);
        res.json({ message: 'Categoria eliminada correctamente' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

export const insertarProducto = async (req, res) => {
    try {
    const resultado = await insertaProd(req.body);
    res.status(201).json(resultado);
    } catch (error) {
    res.status(500).json({ error: error.message });
    }
}; 

export const muestraProductos = async (req, res) => {
    try {
    const resultado = await obtTodoProd();
    res.json(resultado);
    } catch (error) {
    res.status(500).json({ error: error.message });
    }
};

export const muestraIDProductos = async (req, res) => {
    try {
    const resultado = await obtTodoIDProd(req.params.id);
    res.json(resultado);
    } catch (error) {
    res.status(500).json({ error: error.message });
    }
};

export const actualizaProducto = async (req, res) => {
    try {
        const resultado = await actualizaProd(req.params.id, req.body);
        res.json(resultado);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

export const actualizaStock = async (req,res) => {
    try {
        const resultado = await actualiza_stock(req.params.id, req.body);
        res.json(resultado);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

