import {db} from '../config/db.js';

export const obtTodoCategoria = async () => {
    const [resultado] = await db.query('SELECT * FROM categorias');
    return resultado;
};

export const obtTodoIDCategoria = async (id) => {
    const [resultado] = await db.query('SELECT * FROM categorias WHERE id = ?',[id]);
    return resultado;
};

export const insertaCategoria = async (categorias) => {
    const { nombre, descripcion } = categorias;
    const [resultado] = await db.query('INSERT INTO categorias(nombre, descripcion) VALUES (?,?)',[nombre, descripcion]);
    return { id: resultado.insertId, ...categorias };
};

export const actualizaCat = async (id,categorias) => {
    const { nombre, descripcion } = categorias;
    await db.query('UPDATE categorias SET nombre = ?, descripcion = ? WHERE id = ?',[nombre, descripcion,id]);
    return { id, ...categorias };
};

export const eliminaCat = async (id) => {
    await db.query('DELETE FROM categorias  WHERE id = ?',[id]);
    return { id };
};

export const insertaProd = async (productos) => {
    const {nombre, precio, stock, categoria_id} = productos;
    const [resultado] = await db.query('INSERT INTO productos (nombre, precio, stock, categoria_id) VALUES (?, ?, ?, ?)',[nombre, precio, stock, categoria_id]);
    return { id: resultado.insertId, ...productos};
};

export const obtTodoProd = async () => {
    const [resultado] = await db.query('SELECT p.*, c.nombre AS categoria FROM productos p JOIN categorias c ON p.categoria_id = c.id');
    return resultado;
};

export const obtTodoIDProd = async (id) => {
    const [resultado] = await db.query('SELECT p.*, c.nombre AS categoria FROM productos p JOIN categorias c ON p.categoria_id = c.id WHERE p.id = ?', [id]);
    return resultado;
};

export const actualizaProd= async (id,productos) => {
    const { nombre, precio, stock, categoria_id } = productos;
    await db.query('UPDATE productos SET nombre=?, precio=?, stock=?, categoria_id=?, fecha_act=NOW() WHERE id=?',[nombre, precio, stock, categoria_id, id]);
    return { id, ...productos };
};

export const actualiza_stock= async (id,producto) => {
    const [resultado] = await db.query('UPDATE productos SET stock = stock + ? WHERE id = ?',[producto.cantidad, id]);
    return { resultado };
};

